/* Verbesserte Version von TicTacToe
    "ALLES" bekommt eine eigene Klasse ;-)
    (c) 2017 HUH + FIAEU16WS 
*/
package tag_06_tictactoe_2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.TextField;

/**
 *
 * @author hhieninger
 */
public class Infozeile extends Panel {
    TextField textFeld;

    public Infozeile() {
        super.setBackground(Color.RED);
        textFeld = new TextField();                
        setLayout(new GridLayout(1, 1));
        super.add(textFeld);
    }
    
    void ausgeben(String s){
        textFeld.setText(s);
    }
}
