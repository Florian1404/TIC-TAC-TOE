/* Verbesserte Version von TicTacToe
    "ALLES" bekommt eine eigene Klasse ;-)
    (c) 2017 HUH + FIAEU16WS 
*/
package tag_06_tictactoe_2;

import java.awt.Button;
import java.awt.HeadlessException;

/**
 *
 * @author hhieninger
 */
public class TTTKnopf extends Button {
    boolean besetzt = false;
    public TTTKnopf() throws HeadlessException {
        this.setActionCommand("TTT");
    }
    /**
     * Wenn der Knopf frei ist, mit dem Symbol des aktuellen Spielers belegen
     * @param aktSpieler aktueller Spieler
     * @return konnte der Knopf gerade belegt werden? JA/NEIN
     */
    boolean markieren(Spieler aktSpieler){
        if (!besetzt){
            setLabel(aktSpieler.toString());
            besetzt = true; // Knopf wurde markiert
            return true;
        }   else {
            return false; // Knopf war schon markiert
        }
        
    }

    void zuruecksetzen() {
        setLabel("");
        besetzt = false;

    }
    
    
}
