/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Panel;

/**
 *
 * @author hhieninger
 */
public class Statistik extends Panel {

    int anzahlZaehler = 3;
    Zaehler[] zaehler = new Zaehler[3];
    Spieler spielerX;
    Spieler spielerO;
    Spieler unentschieden = new Spieler("---");
    Spieler[] spieler = new Spieler[3];

    public Statistik(Spieler spielerX, Spieler spielerO) {
        this.spieler = new Spieler[3];
        super.setBackground(Color.GREEN);
        super.setLayout(new GridLayout(anzahlZaehler, 1, 0, 3));

        this.spieler[0] = spielerX;
        this.spieler[1] = unentschieden;
        this.spieler[2] = spielerO;

        for (int i = 0; i < zaehler.length; i++) {
            zaehler[i] = new Zaehler(this.spieler[i]);
            super.add(zaehler[i]);

        }
    }

    void hochzaehlen(Spieler spieler) {
        switch (spieler.toString()) {
            case Spieler.SYMBOL_X:
                zaehler[0].hochzaehlen();
                break;
            case Spieler.SYMBOL_O:
                zaehler[2].hochzaehlen();
                break;
            default:
                zaehler[1].hochzaehlen();
                break;
        }
    }
}
