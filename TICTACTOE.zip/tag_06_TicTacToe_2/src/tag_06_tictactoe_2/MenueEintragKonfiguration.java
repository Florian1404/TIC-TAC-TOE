/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

/**
 *
 * @author hhieninger
 */
public class MenueEintragKonfiguration {

    String beschriftung;
    String kommando;

    public MenueEintragKonfiguration(String beschriftung, String kommando) {
        this.beschriftung = beschriftung;
        this.kommando = kommando;
    }

    

}
