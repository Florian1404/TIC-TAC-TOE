/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

/**
 *
 * @author hhieninger
 */
public class Spieler {

    static final String SYMBOL_X = "X";
    static final String SYMBOL_O = "O";
    
    String symbol;

    public Spieler(String symbol) {
        this.symbol = symbol;
    }

    @Override
    public String toString() {
        return this.symbol;
    }

}
