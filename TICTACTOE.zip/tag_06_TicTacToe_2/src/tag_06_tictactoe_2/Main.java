package tag_06_tictactoe_2;

/**
 *
 * @author fhuschka
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Fenster fenster = new Fenster();
       fenster.machmal();
    }
    
}
