/* Verbesserte Version von TicTacToe
    "ALLES" bekommt eine eigene Klasse ;-)
    (c) 2017 HUH + FIAEU16WS 
*/
package tag_06_tictactoe_2;

import java.awt.Color;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;

/**
 *
 * @author fhuschka
 */
public class Zaehler extends Panel {
    Label beschriftung;
    TextField anzeige;
    int aktuellerWert = 0;
    
    
    public Zaehler(Spieler spieler) {
        super.setBackground(Color.white);
        
        System.out.println("spieler: " + spieler);
        beschriftung = new Label(spieler.toString());
        anzeige = new TextField("HIER SOLL DANN EINE ZAHL STEHEN");
        super.add(beschriftung);
        super.add(anzeige);
    }

    void hochzaehlen() {
        aktuellerWert++;
        anzeige.setText("" + aktuellerWert);
    }
    
    
}
