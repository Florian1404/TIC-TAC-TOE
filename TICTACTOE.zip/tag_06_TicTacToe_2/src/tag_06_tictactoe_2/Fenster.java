/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.HeadlessException;

/**
 *
 * @author hhieninger
 */
public class Fenster extends Frame {

    final int BREITE = 400;
    final int HOEHE = 300;
    final String TITEL = "TIC TAC TOE Version 2.0 ;-)";
    final Dimension GROESSE = new Dimension(BREITE, HOEHE);

    Steuerung steuerung;
    Infozeile infozeile;
    Statistik statistik;
    Spielfeld spielfeld;
    Schiedsrichter schiedsrichter;
    Spieler spielerX;
    Spieler spielerO;

    public Fenster() throws HeadlessException {
        super.addWindowListener(new Hausmeister());
        super.setSize(GROESSE);      // Fenstergröße festlegen
        super.setLocationRelativeTo(null); // Fenster zentriert auf dem Bildschirm
        super.setTitle(TITEL);

        spielerX = new Spieler(Spieler.SYMBOL_X);
        spielerO = new Spieler(Spieler.SYMBOL_O);

        steuerung = new Steuerung();
        super.setMenuBar(steuerung);

        infozeile = new Infozeile();
        steuerung.setzeInfozeile(infozeile);
        super.add(infozeile, BorderLayout.SOUTH);

        statistik = new Statistik(spielerX, spielerO);
        super.add(statistik, BorderLayout.NORTH);

        spielfeld = new Spielfeld();
        super.add(spielfeld, BorderLayout.CENTER);

        schiedsrichter = new Schiedsrichter(spielfeld, infozeile, statistik);
        
        spielfeld.setzeSchiedsrichter(schiedsrichter);
        schiedsrichter.spielerAnmelden(spielerX, spielerO);
        schiedsrichter.setAktSpieler(spielerX);

        // TESTKNOPF: Funktioniert unsere Statistik
        Button testKnopf = new Button("TEST");
        testKnopf.addActionListener(schiedsrichter);
        super.add(testKnopf, BorderLayout.WEST);
    }

    void machmal() {
        setVisible(true);
    }

}
