/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author hhieninger
 */
public class Hausmeister extends WindowAdapter {

    @Override
    public void windowClosing(WindowEvent e) {
        e.getWindow().dispose();
    }

}
