/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

import java.awt.HeadlessException;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Wir sollten noch ActionCommands verwenden, weil sich sonst Tippfehler in der
 * switch/case-Anweisung häufen Exit-Code 123 bedeutet unbekannter Menübefehl,
 * du Praktikant!
 *
 * @author hhieninger
 */
public class Steuerung extends MenuBar implements ActionListener {

    final String CMD_ENDE = "ENDE";
    final String CMD_SPIELEN = "SPIELEN";
    final String CMD_FARBEN = "FARBEN";
    final String CMD_HILFE_FARBEN = "HILFE FARBEN";
    final String CMD_ABSTAENDE = "ABSTÄNDE";
    final String CMD_HILFE_ABSTAENDE = "HILFE ABSTÄNDE";
    final String CMD_HILFE_EINSTELLUNGEN = "???";

    Infozeile infozeile;
    String[][] menues_ALT = {
        {"Datei",
            "Beenden", CMD_ENDE},
        {"Spielen",
            "Jetzt spielen", CMD_SPIELEN},
        {"Einstellungen",
            "Farben", CMD_FARBEN,
            "Abstände", CMD_ABSTAENDE},
        {"Hilfe",
            "Einstellungen", CMD_HILFE_EINSTELLUNGEN,
            "Farben", CMD_HILFE_FARBEN,
            "Abstände", CMD_HILFE_ABSTAENDE}
    };

    // Kombination von Menüeinträgen und zuständigen ActionCommands
    MenueKonfiguration[] menues = {
        new MenueKonfiguration("Datei",
        new MenueEintragKonfiguration[]{
            new MenueEintragKonfiguration("Beenden", CMD_ENDE)
        }),
        new MenueKonfiguration("Spielen",
        new MenueEintragKonfiguration[]{
            new MenueEintragKonfiguration("Jetzt spielen", CMD_SPIELEN)
        }),
        new MenueKonfiguration("Einstellungen",
        new MenueEintragKonfiguration[]{
            new MenueEintragKonfiguration("Farben", CMD_FARBEN),
            new MenueEintragKonfiguration("Abstände", CMD_ABSTAENDE)
        }),
        new MenueKonfiguration("Hilfe",
        new MenueEintragKonfiguration[]{
            new MenueEintragKonfiguration("Einstellungen", CMD_HILFE_EINSTELLUNGEN),
            new MenueEintragKonfiguration("Farben", CMD_HILFE_FARBEN),
            new MenueEintragKonfiguration("Abstände", CMD_HILFE_ABSTAENDE)
        })
    };

    public Steuerung() throws HeadlessException {

        for (MenueKonfiguration menue : menues) {
            Menu m = new Menu(menue.beschriftung);

            for (MenueEintragKonfiguration menueEintrag
                    : menue.menueEintragKonfigurationen) {
                MenuItem mi = new MenuItem(menueEintrag.beschriftung);
                mi.setActionCommand(menueEintrag.kommando);
                mi.addActionListener(this);
                m.add(mi);
            }

            this.add(m);
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        System.out.println(e.getActionCommand());
        switch (e.getActionCommand()) {
            default:
                System.exit(123); // Sollte eigentlich NIE vorkommen...
                break;
            case CMD_ENDE:
                System.exit(0); //                 
                break;
            case CMD_SPIELEN:
                infozeile.ausgeben("Du willst also " + e.getActionCommand());
                break;
            case CMD_FARBEN:
                infozeile.ausgeben("Ich kann noch keine Farben ändern!");
                break;
            case CMD_ABSTAENDE:
                infozeile.ausgeben("Kauf Dir die Premiumversion!");
                break;
            case CMD_HILFE_EINSTELLUNGEN:
                infozeile.ausgeben("RTFM");
                break;
            case CMD_HILFE_FARBEN:
                infozeile.ausgeben("Da die Farben noch nicht zu ändern sind, gibt es auch keine Hilfe");
                break;
            case CMD_HILFE_ABSTAENDE:
                infozeile.ausgeben("Da die Abstände noch nicht zu ändern sind, gibt es auch keine Hilfe");
                break;
        }
    }

    void setzeInfozeile(Infozeile infozeile) {
        this.infozeile = infozeile;
    }
}
