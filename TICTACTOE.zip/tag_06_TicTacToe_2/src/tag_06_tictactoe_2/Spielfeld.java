/* Verbesserte Version von TicTacToe
    "ALLES" bekommt eine eigene Klasse ;-)
    (c) 2017 HUH + FIAEU16WS 
*/
package tag_06_tictactoe_2;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Panel;

/**
 *
 * @author hhieninger
 */
public class Spielfeld extends Panel{
    final int BREITE = 3;
    final int HOEHE = 3;
    TTTKnopf[][] tttKnopf = new TTTKnopf[HOEHE][BREITE];
    Schiedsrichter schiedsrichter;

    public Spielfeld() {
        super.setBackground(Color.BLUE);
        
        setLayout(new GridLayout(HOEHE, BREITE));
        
        for (int z = 0; z < HOEHE; z++){
            for (int s = 0; s < BREITE; s++){
                tttKnopf[z][s] = new TTTKnopf();
                super.add(tttKnopf[z][s]);
            }
        }
    }

    void setzeSchiedsrichter(Schiedsrichter schiedsrichter) {
        this.schiedsrichter = schiedsrichter;
    for (TTTKnopf[] tttK : tttKnopf) {
        for (TTTKnopf k : tttK){
            k.addActionListener(schiedsrichter);
            
        }
        
                
            }
    }
    
}
