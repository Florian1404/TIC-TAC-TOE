/* Verbesserte Version von TicTacToe
 "ALLES" bekommt eine eigene Klasse ;-)
 (c) 2017 HUH + FIAEU16WS 
 */
package tag_06_tictactoe_2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author fhuschka
 */
public class Schiedsrichter implements ActionListener {

    Spielfeld spielfeld;
    Infozeile infozeile;
    Statistik statistik;
    Spieler spielerX;
    Spieler spielerO;
    Spieler unentschieden;
    private Spieler aktSpieler;
    boolean spielBeendet = false;
    int benutzteKnoepfe = 0;

    Schiedsrichter(Spielfeld spielfeld, Infozeile infozeile, Statistik statistik) {
        this.spielfeld = spielfeld;
        this.infozeile = infozeile;
        this.statistik = statistik;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        switch (e.getActionCommand()) {
            case "TEST":
                //statistik.hochzaehlen(new Spieler("---"));
                neuesSpiel();

                break;
            case "TTT":
                if (spielBeendet) {
                    infozeile.ausgeben("Aus is");
                    return;
                }
                //infozeile.ausgeben("BRAVER KNOPF");
                TTTKnopf aktKnopf = (TTTKnopf) e.getSource();
                if (aktKnopf.markieren(getAktSpieler())) {
                    if (gewonnen()) {
                        statistik.hochzaehlen(aktSpieler);
                        spielBeendet = true;
                    } else if (unentschieden()){
                        statistik.hochzaehlen(new Spieler("---"));
                    }

                    spielerWechsel();
                } else {
                    infozeile.ausgeben("Dieses Feld ist schon belegt!");

                }
                break;

            default:
                infozeile.ausgeben("BÖSER KNOPF, PFUI!");
                break;
        }
    }

    /**
     * @return the aktSpieler
     */
    public Spieler getAktSpieler() {
        return aktSpieler;
    }

    /**
     * @param aktSpieler the aktSpieler to set
     */
    public void setAktSpieler(Spieler aktSpieler) {
        this.aktSpieler = aktSpieler;
    }

    public void spielerWechsel() {
        if (aktSpieler == spielerX) {
            aktSpieler = spielerO;
        } else {
            aktSpieler = spielerX;
        }
        benutzteKnoepfe++;

    }

    public void spielerAnmelden(Spieler spielerX, Spieler spielerO) {
        this.spielerX = spielerX;
        this.spielerO = spielerO;
    }

    boolean gewonnen() {
        TTTKnopf[][] knoepfe = spielfeld.tttKnopf;
        String avatar = this.aktSpieler.toString();
        return //Zeile 0 dreimal gleich
                ((knoepfe[0][0].getLabel() == avatar)
                && (knoepfe[0][1].getLabel() == avatar)
                && (knoepfe[0][2].getLabel() == avatar))
                // oder
                || ((knoepfe[0][0].getLabel() == avatar)
                && (knoepfe[1][1].getLabel() == avatar)
                && (knoepfe[2][2].getLabel() == avatar))
                //oder
                || ((knoepfe[2][0].getLabel() == avatar)
                && (knoepfe[2][1].getLabel() == avatar)
                && (knoepfe[2][2].getLabel() == avatar))
                // oder
                || ((knoepfe[0][0].getLabel() == avatar)
                && (knoepfe[1][0].getLabel() == avatar)
                && (knoepfe[2][0].getLabel() == avatar))
                //oder
                || ((knoepfe[0][1].getLabel() == avatar)
                && (knoepfe[1][1].getLabel() == avatar)
                && (knoepfe[2][1].getLabel() == avatar))
                // oder
                || ((knoepfe[0][2].getLabel() == avatar)
                && (knoepfe[1][2].getLabel() == avatar)
                && (knoepfe[2][2].getLabel() == avatar))
                // oder
                || ((knoepfe[0][0].getLabel() == avatar)
                && (knoepfe[1][1].getLabel() == avatar)
                && (knoepfe[2][2].getLabel() == avatar))
                // oder
                || ((knoepfe[0][2].getLabel() == avatar)
                && (knoepfe[1][1].getLabel() == avatar)
                && (knoepfe[2][0].getLabel() == avatar));

    }

    boolean unentschieden() {
        return !gewonnen() && benutzteKnoepfe == 8;
    }

    void neuesSpiel() {
        for (TTTKnopf[] ttt : spielfeld.tttKnopf) {
            for (TTTKnopf k : ttt) {
                k.zuruecksetzen();
            }
        }
        spielBeendet = false;
        benutzteKnoepfe = 0;
    }

}
